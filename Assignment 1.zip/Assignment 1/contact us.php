<!DOCTYPE html>
<html lang="en">
<head>
    <title>Contact Us - Travel With Us</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@200;300;400&family=Poppins:wght@100;200;300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">Travel With Us</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="about.php">About</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="contact us.php">Contact Us</a>
                </li>
            </ul>
            <form class="d-flex" role="search">
                <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                <button class="btn btn-outline-success" type="submit">Search</button>
            </form>
        </div>
    </div>
</nav>

<div class="container">
    <section class="my-5">
        <div class="text-center">
            <h1 class="text">Contact Us</h1>
        </div>

        <div class="row">
            <div class="col-lg-6 col-md-6 col-12">
                <img src="Images/contact us.webp" alt="Contact" class="img-fluid contact-img">
            </div>

            <div class="col-lg-6 col-md-6 col-12 text-center">
                <h3>Contact Information</h3>
                <p>
                    <strong>Address:</strong><br>
                    450 Huntington Rd, Brampton, ON, CA, L6Y 3Z8<br><br>
                    <strong>Email:</strong><br>
                    travelwithus@gmail.com<br><br>
                    <strong>Phone:</strong><br>
                    +1(536)6382-1238
                </p>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-6 col-md-6 col-12 mx-auto">
                <h3>Send Your Message</h3>
                <form class="contact-form" method="post" style="margin: 50px" >
                    <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" id="name" name="name" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" required>
                    </div>
                    <div class="form-group">
                        <label for="subject">Subject</label>
                        <input type="text" id="subject" name="subject" required>
                    </div>
                    <div class="form-group">
                        <label for="message">Message</label>
                        <textarea id="message" name="message" rows="4" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Send Message</button>
                </form>
            </div>
        </div>
    </section>
</div>

<footer>
    <p class="p-3 bg-dark text-white">@TravelWithUs</p>
</footer>

<script src="https://code.jquery.com/jquery-3.6.4.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
