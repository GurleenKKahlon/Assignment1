<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $selectedDestination = $_POST["destination"];
    // Database connection settings
    $db_host = "localhost";
    $db_user = "root";
    $db_password = "1234";
    $db_name = "bookyourtravel";

    // Create a database connection
    $conn = new mysqli($db_host, $db_user, $db_password, $db_name);

    // Check for connection errors
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Retrieve data from the form
    $destination = $_POST["destination"];
    $username = $_POST["Username"];
    $mobile = $_POST["Mobile"];
    $email = $_POST["e-mail"];
    $checkInDate = $_POST["check-in"];
    $checkOutDate = $_POST["check-out"];
    $guests = $_POST["guests"];
    $message = $_POST["message"];

    // SQL query to insert data into a table
    $sql = "INSERT INTO `userinfodata`(`id`, `Destination`, `Name`, `Mobile`, `E-mail`, `Check-in Date`, `Check-out Date`, `Number Of Guests`, `Additional Requests`) 
        VALUES ('$destination', '$username', '$mobile', '$email', '$checkInDate', '$checkOutDate', '$guests', '$message')";


    if ($conn->query($sql) === TRUE) {
        echo "Booking submitted successfully!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }


    // Close the database connection
    $conn->close();
}

