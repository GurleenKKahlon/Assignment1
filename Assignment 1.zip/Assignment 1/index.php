<!DOCTYPE html>
<html lang="en">
<head>
    <title>Home</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@200;300;400&family=Poppins:wght@100;200;300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">Travel With Us</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="about.php">About  </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="contact us.php">Contact us</a>
                </li>
            </ul>
            <form class="d-flex" role="search">
                <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                <button class="btn btn-outline-success" type="submit">Search</button>
            </form>
        </div>
    </div>
</nav>

<div id="demo" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ul class="carousel-indicators">
        <li data-target="#demo" data-slide-to="0" class="active"></li>
        <li data-target="#demo" data-slide-to="1"></li>
        <li data-target="#demo" data-slide-to="2"></li>
        <li data-target="#demo" data-slide-to="3"></li>
    </ul>

    <!-- The Carousel Items -->
    <div class="carousel-inner">
        <div class="carousel-item active">
            <img src="Images/Bali.jpeg" alt="Bali" width="1100" height="500">
            <div class="carousel-caption">
                <h2>Bali</h2>
                <p1>The Heaven on Earth!</p1>
            </div>
        </div>

        <div class="carousel-item">
            <img src="Images/maldives.jpeg" alt="Maldives" width="1100" height="500">
            <div class="carousel-caption">
                <h2>Maldives</h2>
                <p1>Don't Worry! 'Beach' Happy:)</p1>
            </div>
        </div>

        <div class="carousel-item">
            <img src="Images/santorini greece.jpeg" alt="Santorini" width="1100" height="500">
            <div class="carousel-caption">
                <h2>Santorini</h2>
                <p1>The 'Blue & White' Wonderland!</p1>
            </div>
        </div>

        <div class="carousel-item">
            <img src="Images/Sicily Italy.webp" alt="Sicily" width="1100" height="500">
            <div class="carousel-caption">
                <h2>Sicily</h2>
                <p1>God's Paradise!:)</p1>
            </div>
        </div>
    </div>

    <!-- Left and right controls -->
    <a class="carousel-control-prev" href="#demo" data-slide="prev">
        <span class="carousel-control-prev-icon"></span>
    </a>
    <a class="carousel-control-next" href="#demo" data-slide="next">
        <span class="carousel-control-next-icon"></span>
    </a>
</div>

<section class="my-5">
    <div class="text-center">
        <h1 class="text">About us</h1>
    </div>

    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-6 col-md-6 col-12">
                <img src="Images/About us.jpg" alt="Travel" class="img-fluid aboutimg">
            </div>

            <div class="col-lg-6 col-md-6 col-12">
                <h3>
                    "Welcome to our world of wanderlust!"
                </h3>
                <p>At {Travel With Us}, we're not just in the business of planning vacations; we're in the business of creating unforgettable experiences. With a deep-rooted passion for exploration and a commitment to exceptional service,
                    we invite you to embark on journeys that transcend the ordinary. Our team of dedicated travel experts curates every adventure with care, attention to detail, and a deep love for travel. We understand that each traveler is unique,
                    and so are their aspirations. Whether you seek the pristine beaches of exotic destinations, the vibrant tapestry of diverse cultures, or the thrill of adventure, we're here to turn your dreams into reality. As a trusted name in the
                    industry, we take pride in making your journeys safe, seamless, and extraordinary. Welcome to a world of discovery, where every trip is a story waiting to be written.</p>
                <p>"Your journey begins with us. From breathtaking landscapes to unique cultural encounters, we're here to make every step of your adventure extraordinary."</p>
            <a href="about.php" class="btn btn-success">Know More</a>
            </div>
        </div>
    </div>

    <div class="container">
        <form class="travel-form" method="post">
            <h1>Book Your Travel</h1>
            <div class="form-group"
             <label for="destination">Destination</label>
             <select id="destination" name="destination" required>
                <option value="">Select a Destination</option>
                <option value="Bali">Bali</option>
                <option value="santorini">Santorini</option>
                <option value="tokyo">Tokyo</option>
                <option value="rome">Rome</option>
                 <option value="sicily">Sicily</option>
                 <option value="Maldives">Maldives</option>
                 <option value="Ireland">Ireland</option>
                 <option value="others..">Others..</option>

            </select>

            <div class="form-group">
                <label for="username">Name</label>
                <input type="text" id="username" name="Username" required>
            </div>
            <div class="form-group">
                <label for="Mobile">Mobile No</label>
                <input type="number" id="Mobile" name="Mobile" required>
            </div>
            <div class="form-group">
                <label for="e-mail">E-mail</label>
                <input type="email" id="e-mail" name="e-mail" required>
            </div>
            <div class="form-group">
                <label for="check-in">Check-in Date</label>
                <input type="date" id="check-in" name="check-in" required>
            </div>
            <div class="form-group">
                <label for="check-out">Check-out Date</label>
                <input type="date" id="check-out" name="check-out" required>
            </div>
            <div class="form-group">
                <label for="guests">Number of Guests</label>
                <input type="number" id="guests" name="guests" required>
            </div>
            <div class="form-group">
                <label for="message">Additional Requests</label>
                <textarea id="message" name="message" rows="4"></textarea>
            </div>
            <button type="submit">Submit</button>
        </form>
    </div>

</section>

<footer>
    <p class="p-3 bg-dark text-white">@TravelWithUs  </p>
</footer>

    <script src="https://code.jquery.com/jquery-3.6.4.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
