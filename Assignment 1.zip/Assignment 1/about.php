<!DOCTYPE html>
<html lang="en">
<head>
    <title>About Us</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@200;300;400&family=Poppins:wght@100;200;300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">Travel With Us</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="about.php">About  </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="contact us.php">Contact us</a>
                </li>
            </ul>
            <form class="d-flex" role="search">
                <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                <button class="btn btn-outline-success" type="submit">Search</button>
            </form>
        </div>
    </div>
</nav>

<div class="jumbotron">
    <h1>Travel With Us</h1>
    <p>Exploring the Globe, One Adventure at a Time.
        We're a team of avid travelers who believe that the journey is as important as the destination.</p>
</div>

<section class="my-5">
    <div class="text-center">
        <h1 class="text">About us</h1>
    </div>

    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-6 col-md-6 col-12">
                <img src="Images/About us.jpg" alt="Travel" class="img-fluid aboutimg">
            </div>

            <div class="col-lg-6 col-md-6 col-12">
                <h3>
                    "Welcome to our world of wanderlust!"
                </h3>
                <p>At {Travel With Us}, we're not just in the business of planning vacations; we're in the business of creating unforgettable experiences. With a deep-rooted passion for exploration and a commitment to exceptional service,
                    we invite you to embark on journeys that transcend the ordinary. Our team of dedicated travel experts curates every adventure with care, attention to detail, and a deep love for travel. We understand that each traveler is unique,
                    and so are their aspirations. Whether you seek the pristine beaches of exotic destinations, the vibrant tapestry of diverse cultures, or the thrill of adventure, we're here to turn your dreams into reality. As a trusted name in the
                    industry, we take pride in making your journeys safe, seamless, and extraordinary. Welcome to a world of discovery, where every trip is a story waiting to be written.</p>
                <p>"Your journey begins with us. From breathtaking landscapes to unique cultural encounters, we're here to make every step of your adventure extraordinary."</p>
                <a href="about.php" class="btn btn-success">Know More</a>
            </div>
        </div>
    </div>

</body>

<footer>
    <p class="p-3 bg-dark text-white">@TravelWithUs  </p>
</footer>

</html>